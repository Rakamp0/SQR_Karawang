<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="py-12 bg-gray-50 min-h-screen">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            
            
            <div class="mb-8">
                
                
                <?php if(Auth::guard('instansi')->check()): ?>
                    <h2 class="text-3xl font-extrabold text-green-900 tracking-tight">
                        
                        Dashboard <?php echo e(Auth::guard('instansi')->user()->Nama_Instansi); ?> 🏢
                    </h2>
                    <p class="text-gray-500 mt-1">
                        Selamat datang! Silakan pantau dan tindak lanjuti laporan masyarakat yang masuk.
                    </p>
                
                
                <?php else: ?>
                    <h2 class="text-3xl font-extrabold text-green-900 tracking-tight">
                        Dashboard Admin 👮‍♂️
                    </h2>
                    <p class="text-gray-500 mt-1">
                        Selamat datang kembali! Berikut adalah Aduan dan Thread hari ini.
                    </p>
                <?php endif; ?>
            </div>

            
            <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-2 gap-8">
                
                
                <div class="relative overflow-hidden bg-gradient-to-br from-blue-600 to-blue-700 p-8 rounded-2xl text-white shadow-xl transition-all duration-300 hover:scale-[1.02] hover:shadow-blue-200">
                    
                    
                    <div class="absolute -right-10 -top-10 w-40 h-40 bg-white/10 rounded-full blur-3xl"></div>
                    
                    <div class="relative z-10 flex justify-between items-start">
                        <div>
                            <h3 class="text-blue-100 font-semibold uppercase tracking-wider text-sm">Total Pengaduan Masuk</h3>
                            
                            <p class="text-5xl font-black mt-2 tracking-tight"><?php echo e($totalAduan); ?></p>
                        </div>
                        <div class="p-3 bg-white/20 rounded-xl backdrop-blur-md">
                            
                            <svg class="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" />
                            </svg>
                        </div>
                    </div>

                    <div class="mt-8 relative z-10">
                        <a href="<?php echo e(route('admin.pengaduan')); ?>" class="inline-flex items-center gap-2 bg-white text-blue-700 px-5 py-2.5 rounded-xl font-bold text-sm transition hover:bg-blue-50">
                            Kelola Laporan
                            <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 8l4 4m0 0l-4 4m4-4H3" />
                            </svg>
                        </a>
                    </div>
                </div>

                
                <?php if(Auth::guard('petugas')->check()): ?>
                    <div class="relative overflow-hidden bg-gradient-to-br from-green-500 to-emerald-600 p-8 rounded-2xl text-white shadow-xl transition-all duration-300 hover:scale-[1.02] hover:shadow-green-200">
                        
                        
                        <div class="absolute -right-10 -top-10 w-40 h-40 bg-white/10 rounded-full blur-3xl"></div>

                        <div class="relative z-10 flex justify-between items-start">
                            <div>
                                <h3 class="text-green-100 font-semibold uppercase tracking-wider text-sm">Diskusi Warga (Thread)</h3>
                                
                                <p class="text-5xl font-black mt-2 tracking-tight"><?php echo e($totalThread); ?></p>
                            </div>
                            <div class="p-3 bg-white/20 rounded-xl backdrop-blur-md">
                                
                                <svg class="w-8 h-8 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 8h2a2 2 0 012 2v6a2 2 0 01-2 2h-2v4l-4-4H9a1.994 1.994 0 01-1.414-.586m0 0L11 14h4a2 2 0 002-2V6a2 2 0 00-2-2H5a2 2 0 00-2 2v6a2 2 0 002 2h2v4l.586-.586z" />
                                </svg>
                            </div>
                        </div>

                        <div class="mt-8 relative z-10">
                            <a href="<?php echo e(route('admin.thread')); ?>" class="inline-flex items-center gap-2 bg-white text-green-700 px-5 py-2.5 rounded-xl font-bold text-sm transition hover:bg-green-50">
                                Kelola Forum
                                <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2" d="M17 8l4 4m0 0l-4 4m4-4H3" />
                                </svg>
                            </a>
                        </div>
                    </div>
                <?php endif; ?>

            </div>
            
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH D:\KULIAH\SEMESTER 3\Pengembangan Aplikasi Berbasis Web\Tubes\SQR_Karawang\Finalisasi\_SQR_Karawang\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>