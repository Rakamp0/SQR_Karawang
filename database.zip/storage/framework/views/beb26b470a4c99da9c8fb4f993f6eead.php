<?php if (isset($component)) { $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54 = $attributes; } ?>
<?php $component = App\View\Components\AppLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('app-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AppLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
     <?php $__env->slot('header', null, []); ?> 
        <div class="flex justify-between items-center">
            <h2 class="font-semibold text-xl text-gray-800 leading-tight">
                <?php echo e(__('Kelola Pengaduan')); ?>

            </h2>

            
            <?php if(Auth::guard('instansi')->check()): ?>
                
                <span class="bg-blue-100 text-blue-800 text-xs font-medium px-2.5 py-0.5 rounded border border-blue-400">
                    Mode Instansi: <?php echo e(Auth::guard('instansi')->user()->Nama_Instansi); ?>

                </span>
            <?php elseif(Auth::guard('petugas')->check()): ?>
                
                <span class="bg-gray-100 text-gray-800 text-xs font-medium px-2.5 py-0.5 rounded border border-gray-500">
                    Mode Admin 
                </span>
            <?php endif; ?>
        </div>
     <?php $__env->endSlot(); ?>

    <div class="py-12">
        <div class="max-w-7xl mx-auto sm:px-6 lg:px-8">
            
            
            
            <?php if(session('success')): ?>
                <div class="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded relative mb-4" role="alert">
                    <span class="block sm:inline"><?php echo e(session('success')); ?></span>
                </div>
            <?php endif; ?>
            <?php if(session('error')): ?>
                <div class="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative mb-4" role="alert">
                    <span class="block sm:inline"><?php echo e(session('error')); ?></span>
                </div>
            <?php endif; ?>

            <div class="bg-white overflow-hidden shadow-sm sm:rounded-lg">
                <div class="p-6 text-gray-900 overflow-x-auto">
                    
                    
                    <table class="w-full text-sm text-left text-gray-500">
                        <thead class="text-xs text-gray-700 uppercase bg-gray-50">
                            <tr>
                                <th class="px-6 py-3">Tanggal</th>
                                <th class="px-6 py-3">Pelapor</th>
                                <th class="px-6 py-3">Judul & Isi</th>
                                <th class="px-6 py-3">Bukti</th>
                                <th class="px-6 py-3">Status</th>
                                <th class="px-6 py-3">Instansi Tujuan</th>
                                <th class="px-6 py-3 text-center">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            
                            <?php $__currentLoopData = $pengaduans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr class="bg-white border-b hover:bg-gray-50">
                                
                                <td class="px-6 py-4 whitespace-nowrap"><?php echo e(\Carbon\Carbon::parse($p->Tanggal_Pengaduan)->format('d M Y')); ?></td>
                                
                                
                                <td class="px-6 py-4">
                                    <div class="font-bold"><?php echo e($p->masyarakat->Nama_Masyarakat ?? 'Guest'); ?></div>
                                    <div class="text-xs"><?php echo e($p->masyarakat->NIK_Masyarakat ?? '-'); ?></div>
                                </td>

                                
                                <td class="px-6 py-4">
                                    <div class="font-bold text-gray-800"><?php echo e($p->Judul_Pengaduan); ?></div>
                                    <div class="font-light text-gray-800"><?php echo e($p->Kategori); ?></div>
                                    <div class="text-xs mt-1"><?php echo e(Str::limit($p->Deskripsi, 50)); ?></div>
                                </td>

                                
                                <td class="px-6 py-4">
                                    <?php if($p->dokumentasi): ?>
                                        <a href="<?php echo e(url('img-proxy/'.$p->dokumentasi)); ?>" target="_blank" class="text-blue-600 hover:underline text-xs">Lihat Foto</a>
                                    <?php else: ?>
                                        -
                                    <?php endif; ?>
                                </td>

                                
                                <td class="px-6 py-4">
                                    <span class="px-2 py-1 rounded text-xs font-bold
                                        
                                        <?php echo e($p->Keterangan == 'Selesai' ? 'bg-green-100 text-green-700' : 
                                          ($p->Keterangan == 'Ditolak' ? 'bg-red-100 text-red-700' : 
                                          ($p->Keterangan == 'Diproses' ? 'bg-blue-100 text-blue-700' : 
                                          ($p->Keterangan == 'Valid' ? 'bg-indigo-100 text-indigo-700' : 'bg-yellow-100 text-yellow-700')))); ?>">
                                        <?php echo e($p->Keterangan); ?>

                                    </span>
                                </td>

                                
                                <td class="px-6 py-4 text-xs">
                                    <?php echo e($p->instansi->Nama_Instansi ?? '-'); ?>

                                </td>

                                
                                <td class="px-6 py-4">
                                    <form action="<?php echo e(route('admin.pengaduan.update', $p->Id_Pengaduan)); ?>" method="POST" class="flex flex-col gap-2">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PATCH'); ?>

                                        
                                        <?php if(Auth::guard('petugas')->check()): ?>
                                            
                                            
                                            <?php if($p->Keterangan == 'Ditinjau'): ?>
                                                
                                                
                                                <select name="id_instansi" class="text-xs border-gray-300 rounded focus:ring-blue-500 focus:border-blue-500 w-full mb-1" required>
                                                    <option value="">-- Pilih Dinas --</option>
                                                    <?php $__currentLoopData = $listInstansi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $dinas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($dinas->Id_Instansi); ?>"><?php echo e($dinas->Nama_Instansi); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                                
                                                
                                                <div class="flex gap-1">
                                                    <button type="submit" name="status" value="Valid" class="flex-1 text-white bg-green-600 hover:bg-green-700 font-medium rounded text-xs px-2 py-1">
                                                        Validasi
                                                    </button>
                                                    <button type="submit" name="status" value="Ditolak" class="flex-1 text-white bg-red-600 hover:bg-red-700 font-medium rounded text-xs px-2 py-1">
                                                        Tolak
                                                    </button>
                                                </div>
                                            <?php else: ?>
                                                
                                                <span class="text-xs text-center text-gray-400 block italic">Menunggu Instansi</span>
                                            <?php endif; ?>
                                        <?php endif; ?>

                                        
                                        <?php if(Auth::guard('instansi')->check()): ?>
                                            
                                            
                                            <?php if($p->Keterangan == 'Valid'): ?>
                                                <button type="submit" name="status" value="Diproses" class="w-full text-white bg-blue-600 hover:bg-blue-700 font-medium rounded text-xs px-3 py-1">
                                                    Proses Laporan
                                                </button>
                                            
                                            
                                            <?php elseif($p->Keterangan == 'Diproses'): ?>
                                                <button type="submit" name="status" value="Selesai" class="w-full text-white bg-green-600 hover:bg-green-700 font-medium rounded text-xs px-3 py-1">
                                                    Selesaikan
                                                </button>
                                            
                                            
                                            <?php else: ?>
                                                <span class="text-xs text-center text-gray-400 block italic">Selesai</span>
                                            <?php endif; ?>
                                        <?php endif; ?>

                                    </form>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            
                            
                            <?php if($pengaduans->isEmpty()): ?>
                            <tr>
                                <td colspan="7" class="px-6 py-4 text-center text-gray-500 italic">
                                    Belum ada pengaduan yang masuk.
                                </td>
                            </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>

                </div>
            </div>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $attributes = $__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__attributesOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54)): ?>
<?php $component = $__componentOriginal9ac128a9029c0e4701924bd2d73d7f54; ?>
<?php unset($__componentOriginal9ac128a9029c0e4701924bd2d73d7f54); ?>
<?php endif; ?><?php /**PATH D:\KULIAH\SEMESTER 3\Pengembangan Aplikasi Berbasis Web\Tubes\SQR_Karawang\Finalisasi\Hosting\sqr_hosting\resources\views/admin/pengaduan/index.blade.php ENDPATH**/ ?>